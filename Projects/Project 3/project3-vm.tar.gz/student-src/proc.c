#include "proc.h"
#include "mmu.h"
#include "pagesim.h"
#include "va_splitting.h"
#include "swapops.h"
#include "stats.h"

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

/**
 * --------------------------------- PROBLEM 3 - CHECKED --------------------------------------
 * Checkout PDF section 4 for this problem
 * 
 * This function gets called every time a new process is created.
 * You will need to allocate a frame for the process's page table using the
 * free_frame function. Then, you will need update both the frame table and
 * the process's PCB. 
 * 
 * @param proc pointer to process that is being initialized 
 * 
 * HINTS:
 *      - pcb_t: struct defined in pagesim.h that is a process's PCB.
 *      - You are not guaranteed that the memory returned by the free frame allocator
 *      is empty - an existing frame could have been evicted for our new page table.
 * ----------------------------------------------------------------------------------
 */
void proc_init(pcb_t *proc) {
    // DONE: initialize proc's page table.
    	// 1. call the free_frame() fn to choose a free frame in which to place process's page table
    		// 1a. once finding which frame to evict, clear the frame's bits
    		// 1a*: accessing the i-th frame = (i*PAGE_SIZE) + mem
    	// 2. make appropriate flags: protected bit = 1 in order to not evict during execution
    		// 2*: flagging the table entry: (frame_table + freedFrame) 
    	// 3. update PBTR in process's PCB struct
    	
    	pfn_t freedFrame = free_frame();
    	
    	memset((freedFrame * PAGE_SIZE) + mem, 0, PAGE_SIZE);
    	
    	proc->saved_ptbr = freedFrame;
    	
    	(frame_table + freedFrame)->protected = 1;
    	(frame_table + freedFrame)->mapped = 1;
    	(frame_table + freedFrame)->process = proc;	
    	
}

/**
 * --------------------------------- PROBLEM 4 - CHECKED --------------------------------------
 * Checkout PDF section 5 for this problem
 * 
 * Switches the currently running process to the process referenced by the proc 
 * argument.
 * 
 * Every process has its own page table, as you allocated in proc_init. You will
 * need to tell the processor to use the new process's page table.
 * 
 * @param proc pointer to process to become the currently running process.
 * 
 * HINTS:
 *      - Look at the global variables defined in pagesim.h. You may be interested in
 *      the definition of pcb_t as well.
 * ----------------------------------------------------------------------------------
 */
void context_switch(pcb_t *proc) {
    // DONE: update any global vars and proc's PCB to match the context_switch.
    	// 1. update PTBR to refer to new process's page table
    		// 1*: update the PTBR to be the saved_ptbr from proc
    		
	PTBR = proc->saved_ptbr;
}

/**
 * --------------------------------- PROBLEM 8 - CHECKED--------------------------------------
 * Checkout PDF section 8 for this problem
 * 
 * When a process exits, you need to free any pages previously occupied by the
 * process.
 * 
 * HINTS:
 *      - If the process has swapped any pages to disk, you must call
 *      swap_free() using the page table entry pointer as a parameter.
 *      - If you free any protected pages, you must also clear their"protected" bits.
 * ----------------------------------------------------------------------------------
 */
void proc_cleanup(pcb_t *proc) {
    // DONE: Iterate the proc's page table and clean up each valid page
    	// 1. unmap any frames so other processes can use them
    		// for each page in page table
    			// i) check if the pte is valid
    			// ii) if valid: get the fte and unmap; set protected bit to 0
    			// iii) check if it is a swap entry
    			// iv) if swap entry: free using swap_free()
    	// 2. free the page table within the frame table
    		// 2a. set to unprotected
    		// 2b. clear mapped bit
    		
	//pfn_t process_pfn = proc->saved_ptbr;
	
	//pte_t* pte = (pte_t*)(process_pfn * PAGE_SIZE + mem);
	
	
    // for loop through the process's page table
    for (size_t i = 0; i < NUM_PAGES; i++) {
    
    	pte_t * temp = i + (pte_t*)(((*proc).saved_ptbr * PAGE_SIZE) + mem);
    	
    	if(temp->valid){
    		temp->valid = 0;
    		
    		frame_table[(*temp).pfn].mapped = 0;
    		//(temp_fte).mapped = 0;
    	}
    	if(swap_exists(temp)) {
    		swap_free(temp);
    	}

    }
    
    (frame_table + (proc->saved_ptbr))->protected = 0;
    (frame_table + (proc->saved_ptbr))->mapped = 0;
}

#pragma GCC diagnostic pop
