#pragma once

#include "mmu.h"

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

/**
 * --------------------------------- PROBLEM 1 - CHECKED--------------------------------------
 * Checkout PDF Section 3 For this Problem
 *
 * Split the virtual address into its virtual page number and offset.
 * 
 * HINT: 
 *      -Examine the global defines in pagesim.h, which will be necessary in 
 *      implementing these functions.
 * ----------------------------------------------------------------------------------
 */
static inline vpn_t vaddr_vpn(vaddr_t addr) {
    // DONE: return the VPN from virtual address addr.
    	// 1. grabbing the higher order of bits
    	// 2. return the virtual page number = used to find physical frame number
    return addr / PAGE_SIZE;
}

static inline uint16_t vaddr_offset(vaddr_t addr) {
    // DONE: return the offset into the frame from virtual address addr.
    	// 1. grab the lower order of bits
    	// 2. return the offset = used to get specific entry/page 
    	// from the PFN start address in mem
    return addr % PAGE_SIZE;
}

#pragma GCC diagnostic pop
