#include "mmu.h"
#include "pagesim.h"
#include "swapops.h"
#include "stats.h"

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

/**
 * --------------------------------- PROBLEM 6 - CHECKED --------------------------------------
 * Checkout PDF section 7 for this problem
 * 
 * Page fault handler.
 * 
 * When the CPU encounters an invalid address mapping in a page table, it invokes the 
 * OS via this handler. Your job is to put a mapping in place so that the translation 
 * can succeed.
 * 
 * @param addr virtual address in the page that needs to be mapped into main memory.
 * 
 * HINTS:
 *      - You will need to use the global variable current_process when
 *      altering the frame table entry.
 *      - Use swap_exists() and swap_read() to update the data in the 
 *      frame as it is mapped in.
 * ----------------------------------------------------------------------------------
 */
void page_fault(vaddr_t addr) {
   // DONE: Get a new frame, then correctly update the page table and frame table
	// 1. get the pte for the addr
		// 1a. get the vpn and offset for addr
		// 1b. calculate pte = mem + vpn + (PTBR * PAGE_SIZE)
	// 2. get PFN of the new frame using free_frame()
		// 2a. update page table entry and flags/values
		// 2b. update flags in the frame table entry
			//2b*: use current_process to update/set vals for fte
	// 3. check for an existing swap for pte
		// 3a. if swap entry exists: use swap_read() to read the saved frame into new frame
			// 3a*. in current page table, update mapping from VPN to new PFN
		// 3b. no swap: clear the new frame
	stats.page_faults++;
	
		
	
	vpn_t address_vpn = vaddr_vpn(addr);
	
	//uint16_t address_OFFSET = vaddr_offset(addr);
	
	pte_t* pte = (pte_t *)(mem + (PTBR * PAGE_SIZE)) + address_vpn ;
	
	pfn_t victim = free_frame();

	pte->pfn = victim;
	pte->dirty = 0;
	pte->valid = 1;
	
	fte_t* fte = frame_table + victim;
	
	fte->vpn = address_vpn;
	fte->referenced = 1;
	fte->mapped = 1;
	fte->protected = 0;
	fte->process = current_process;
	
 	if(swap_exists(pte)){
		swap_read(pte, mem + (victim * PAGE_SIZE));
	} else {
		memset(mem + (victim * PAGE_SIZE), 0, PAGE_SIZE);
	}
	
	
}

#pragma GCC diagnostic pop
