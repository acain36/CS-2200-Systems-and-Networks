#include "stats.h"

/* The stats. See the definition in stats.h. */
stats_t stats;

/**
 * --------------------------------- PROBLEM 10 - CHECKED --------------------------------------
 * Checkout PDF section 10 for this problem
 * 
 * Calulate the total average time it takes for an access
 * 
 * HINTS:
 * 		- You may find the #defines in the stats.h file useful.
 * 		- You will need to include code to increment many of these stats in
 * 		the functions you have written for other parts of the project.
 * -----------------------------------------------------------------------------------
 */
void compute_stats() {
	// AMAT = [(total access time) + (total page fault time) + (total write back time)] / accesses
	
	double total_access_time = MEMORY_ACCESS_TIME * stats.accesses;
	double total_pagefault_time = DISK_PAGE_READ_TIME * stats.page_faults;
	double total_writeback_time = DISK_PAGE_WRITE_TIME * stats.writebacks;
	
	stats.amat = (total_access_time + total_pagefault_time + total_writeback_time)/
		(double)(stats.accesses);
}
